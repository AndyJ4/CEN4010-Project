public class SalariedEmployee extends Employee{
    double salary;

    public SalariedEmployee(){
        this("No name", new Date(), 0.0);
    }
    public SalariedEmployee(String name, Date hireDate,double salary){
        super(name, hireDate);
        setSalary(salary);
    }
    public void setSalary(double salary) {
        if(salary >= 0) {
            this.salary = salary;
        }
        else {
            System.out.println("Salary cannot be negative");
            System.exit(0);
        }
    }
    public double getSalary() {
        return salary;
    }
    public String toString(){
        return super.toString() + " at Salary " + getSalary();
    }
public boolean equals(SalariedEmployee otherEmployee){
        return super.equals(otherEmployee) && salary == otherEmployee.salary;
}
}

public class Billing {
    String Patient;
    String Doctor;
    double due;


    public Billing(){
        this("No name", "No name", 0.0);
    }

    public Billing(String Patient, String Doctor, double due){
        if (Patient == null && Doctor == null && due < 0){
            System.out.println("Error creating billing");
            System.exit(0);
        }
        this.Patient = Patient;
        this.Doctor = Doctor;
        this.due = due;
    }

    public String getPatient() {
        return Patient;
    }

    public void setPatient(String patient) {
        Patient = patient;
    }

    public String getDoctor() {
        return Doctor;
    }

    public void setDoctor(String doctor) {
        Doctor = doctor;
    }

    public double getDue() {
        return due;
    }

    public void setDue(double due) {
        this.due = due;
    }

    public String toString(){
        return("Patient: " + getPatient() + '\n' + "Doctor: " + getDoctor() +'\n' + "Amount Due: $" + getDue());
    }


    public boolean equals(Billing otherBilling){
        return this.Patient == otherBilling.Patient && this.Doctor == otherBilling.Doctor && this.due == otherBilling.due;
    }

}

public class Person {
    private String name;

    public Person () {
        this("No name");
    }
    public Person(String name) {
        if (name == null){
            System.out.println("Error creating person");
                    System.exit(0);
        }
        this.name = name;
    }
    public Person (Person object){

    }
    public String getName(){
        return name;
    }
    public String setName(String name) {
      this.name = name;
        return name;
    }
    public String toString(){
     return (getName());
    }
    public boolean equals(Person other){
        return(this.name.equals(other.getName()));
    }
}

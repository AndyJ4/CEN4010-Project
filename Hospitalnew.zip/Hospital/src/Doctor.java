
public class Doctor extends SalariedEmployee {
    String Speciality;
    double VisitFee;

    public Doctor() {
        this("No name", new Date(), 0.0, "No speciality", 0.0);
    }

    public Doctor(String name, Date hireDate, double Salary, String Speciality, double VisitFee) {
        super(name, hireDate, Salary);
        setSpeciality(Speciality);
        setVisitFee(VisitFee);
    }

    public void setSpeciality(String Speciality) {
        if (Speciality == null) {
            System.out.println(" ");
            System.exit(0);

        }
        this.Speciality = Speciality;
    }

    public String getSpeciality() {
        return Speciality;
    }

    public double getVisitFee() {
        return VisitFee;
    }

    public void setVisitFee(double visitFee) {
        VisitFee = visitFee;
    }

    public String toString() {
        return super.toString() + '\n' + " The speciality is " + getSpeciality() + " and visit fee is $" + getVisitFee();
    }
    public boolean equals(Doctor otherSalariedEmployee){
        return super.equals(otherSalariedEmployee) && Speciality == otherSalariedEmployee.Speciality && VisitFee == otherSalariedEmployee.VisitFee;
    }
}

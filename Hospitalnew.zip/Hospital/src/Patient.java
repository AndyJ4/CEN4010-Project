public class Patient extends Person {
String Doctor;
    public Patient(){
        this("No name", "No name");
    }
    public Patient(String name, String Doctor){
super(name);
        if(name==null||Doctor==null) {
            System.out.println("Error creating the patient");
            System.exit(0);
        }
        this.Doctor = Doctor;

    }

    public String getDoctor() {
        return Doctor;
    }

    public void setDoctor(String doctor) {
        Doctor = doctor;
    }


    public String toString() {
       return "The patient is: " + super.getName() + ", Primary doctor is: " + getDoctor();
    }


    public boolean equals(Patient otherPerson) {
        return super.equals(otherPerson) && Doctor == otherPerson.Doctor;
    }
}
public class Employee extends Person{
    private Date hireDate;

public Employee(){
    this("No name", new Date());
}
public Employee(String name, Date hireDate){
    super(name);
    if(name==null||hireDate==null) {
        System.out.println("Error creating the Employee");
        System.exit(0);
    }
    this.hireDate = new Date(hireDate);

}
public void setHireDate(Date hireDate){
    if(hireDate==null) {
        System.out.println("It's a null date!");
    }
    else {
        this.hireDate=new Date(hireDate);
    }
}
    public Date getHireDate() {
    return hireDate;
    }

    public String toString(){
return "The doctor " + super.toString() + " was hired on " + getHireDate();
    }

    public boolean equals (Employee otherPerson){
        return super.equals(otherPerson) && hireDate == otherPerson.hireDate;
    }

}


public class Main {
    public static void main(String[] args) {
        double total;

        Doctor Kop = new Doctor("Kop", new Date(6, 8, 2001), 75555, "Pediatrician", 150);
        System.out.println(Kop);
        Doctor Lis = new Doctor("Lis", new Date(3, 27, 2002), 54643, "Orthodontist", 132.75);
        System.out.println(Lis);
        Doctor Nip = new Doctor("Nip", new Date(2, 15, 2006), 60500, "Obstetrician", 75);
        System.out.println(Nip);

        System.out.println(" ");

        System.out.println("*Patient's Information*");
        Patient Fred = new Patient("Fred", "Kop");
        System.out.println(Fred);
        Patient Dan = new Patient("Dan", "Lis");
        System.out.println(Dan);
        Patient Luffy = new Patient("Luffy", "Nip");
        System.out.println(Luffy);

        System.out.println(" ");

        System.out.println("*Billing Information*");
        Billing fred = new Billing("Fred", "Kop", 150.0);
        System.out.println(fred);
        Billing dan = new Billing("Dan", "Lis", 132.75);
        System.out.println(dan);
        Billing luffy = new Billing("Luffy", "Nip", 75);
        System.out.println(luffy);

total = luffy.due + fred.due + dan.due;

        System.out.println(" ");
        System.out.println("The total income from billing records is: $" + total);
    }
}